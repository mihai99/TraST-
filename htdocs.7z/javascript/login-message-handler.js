function disposeMessage() {
    let message = document.getElementById("login-success");
    message.style.display = "none";
}