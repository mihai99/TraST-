function openMobileMenu() {
    document.getElementsByClassName("nav-btns")[0].style.right="0px";
}
function closeMobileMenu() {
    document.getElementsByClassName("nav-btns")[0].style.right="-100%";
}