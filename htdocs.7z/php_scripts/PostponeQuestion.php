<?php 
     require_once('../controllers/questionsController.php');
     echo QuestionsController::postPoneQuestion();
?>